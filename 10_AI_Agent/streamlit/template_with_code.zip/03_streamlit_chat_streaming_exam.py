# 03_streamlit_chat_streaming_exam.py (refactored)

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import streamlit as st

# 환경변수 로드는 모듈 최상단에서 한 번만 수행
load_dotenv()

HISTORY_KEY = "chat_history"


@st.cache_resource
def get_model():
    # OpenAI GPT 모델 연동 (무거운 리소스이므로 캐싱)
    return ChatOpenAI(model="gpt-5-mini")


def get_prompt_template():
    # 정적 객체라 캐싱 이득이 거의 없어 일반 함수로 변경
    return ChatPromptTemplate(
        [
            {"role": "system", "content": "당신은 유능한 인공지능 Assistant입니다."},
            MessagesPlaceholder("history"),
            {"role": "user", "content": "{query}"},
        ]
    )


def add_message(role, content):
    """대화 한 건을 session_state에 저장."""
    st.session_state[HISTORY_KEY].append({"role": role, "content": content})


model = get_model()
prompt = get_prompt_template()

if HISTORY_KEY not in st.session_state:
    st.session_state[HISTORY_KEY] = []

st.title("Chatbot Service")

######################################
# 기존 대화내역 출력
# - session_state 저장된 대화내역을 chat_message()를 이용해 출력
######################################
for chat in st.session_state[HISTORY_KEY]:
    with st.chat_message(chat["role"]):
        st.write(chat["content"])

user_input = st.chat_input("User:")

if user_input:  # 사용자가 질문을 입력하면
    # 사용자 질문을 출력하고 먼저 저장 (스트리밍 실패 시에도 유실 방지)
    with st.chat_message("user"):
        st.write(user_input)
    add_message("user", user_input)

    # PromptTemplate으로 PromptValue 생성
    prompt_value = prompt.invoke(
        {"query": user_input, "history": st.session_state[HISTORY_KEY]}
    )

    # llm에 요청 - stream()
    with st.chat_message("ai"):
        try:
            # generator가 값을 제공하는대로 출력하고 최종 출력 내용을 반환
            response = st.write_stream(model.stream(prompt_value))
        except Exception as e:
            st.error(f"응답 생성 중 오류가 발생했습니다: {e}")
            response = None

    # 정상 응답을 받았을 때만 대화 내역에 저장
    if response:
        add_message("ai", response)


# cd streamlit
#  .....\streamlit>
# uv run streamlit run "03_streamlit_chat_streaming_exam copy.py"

# 02_streamlit_chat_llm_exam.py

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import streamlit as st

# 환경변수 로드는 모듈 최상단에서 한 번만 수행
load_dotenv()


@st.cache_resource
def get_model():
    # OpenAI GPT 모델 연동 (무거운 리소스이므로 캐싱)
    return ChatOpenAI(model="gpt-5-mini")


def get_prompt_template():
    # 정적 객체라 캐싱 이득이 거의 없어 일반 함수로 변경
    return ChatPromptTemplate(
        [
            {"role": "system", "content": "당신은 유능한 인공지능 Assistant입니다."},
            MessagesPlaceholder("history"),
            {"role": "user", "content": "{query}"},
        ]
    )


def add_message(role, content):
    """대화 한 건을 session_state에 저장."""
    st.session_state["chat_history"].append({"role": role, "content": content})


model = get_model()
prompt = get_prompt_template()

if "chat_history" not in st.session_state:
    st.session_state["chat_history"] = []

st.title("Chatbot Service")
user_input = st.chat_input("User:")
if user_input:
    # AI 에게 요청
    ## prompt template 이용해서 prompt(PromptValue) 완성
    prompt_value = prompt.invoke({
        "query": user_input,  # 질문
        "history": st.session_state["chat_history"],  # 대화내역
    })

    # 사용자 질문을 먼저 저장 (요청 실패 시에도 유실 방지)
    add_message("user", user_input)

    ## prompt를 model 넣어서 답변을 요청
    try:
        # response: AIMessage 타입. content 속성으로 조회.
        response = model.invoke(prompt_value)
        add_message("ai", response.content)
    except Exception as e:
        st.error(f"응답 생성 중 오류가 발생했습니다: {e}")

######################################
# 출력 - session_state 저장된 대화내역을 chat_message()를 이용해 출력
for chat in st.session_state["chat_history"]:
    with st.chat_message(chat["role"]):
        st.write(chat["content"])


# uv run streamlit run 02_streamlit_chat_llm_exam.py
